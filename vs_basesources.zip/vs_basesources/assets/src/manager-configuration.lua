configuration = {

    ['GeneralSettings'] = {

        ['openKey'] = 'F6'; 

    };    
}